<?php
interface DAO
{
    public function AddStudent();
};

interface DAO2
{
  public function AddMark();
};

interface DAO3
{
    public function PrintPDF();

};

interface DAO4
{
    public function SuccessElements();
    public function FailedElements();
    public function SuccessStudent();


};

interface DAO5
{
    public function AddTeacher();

};
